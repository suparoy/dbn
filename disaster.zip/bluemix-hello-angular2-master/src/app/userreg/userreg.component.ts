import { Component, OnInit, Inject } from '@angular/core';
import { UserRegisterService } from '../services/userregister/userregister.service';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-maps',
  templateUrl: './userreg.component.html',
  styleUrls: ['./userreg.component.css']
})
export class UserRegComponent implements OnInit {
  user: any;
  response: any;
  error: any;
  angForm: FormGroup;
  constructor( @Inject(UserRegisterService) private userRegisterService: UserRegisterService, private fb: FormBuilder) {
    this.user = {};
  }
 
 userRegister() {
  
    this.user["$class"] = "org.disaster.model.NGO";
    console.log("here calling servie.......")
    this.userRegisterService.UserRegister(this.user).subscribe((data: any) => {

      this.response = data;
      console.log(data);
    }, error => {
      this.error = error // error path);

      console.log(this.error);
    }
    );
  }

  ngOnInit() {

    this.angForm = new FormGroup({
      name: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.minLength(5),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      fathername: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.minLength(5),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),

      password: new FormControl(''),
      repassword: new FormControl(''),

      BirthMonth: new FormControl('', Validators.compose([
        Validators.required
      ])),

      gender: new FormControl('', Validators.compose([
        Validators.required
      ])),

      bday: new FormControl('', Validators.compose([
        Validators.required
      ])),

      blood: new FormControl(''),

      phone: new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
        Validators.pattern('^[0-9]+$')
        // Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ]))
  
    })
  }

  account_validation_messages = {
    'name': [
      { type: 'required', message: 'Name is required' },
      { type: 'minlength', message: 'Name must be at least 5 characters long' },
      { type: 'maxlength', message: 'Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Name must contain only letters' }
    ],

     'fathername': [
      { type: 'required', message: 'Name is required' },
      { type: 'minlength', message: 'Name must be at least 5 characters long' },
      { type: 'maxlength', message: 'Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Name must contain only letters' }
    ],

    'email': [
      { type: 'required', message: 'Email is required' },
      // { type: 'minlength', message: 'Email must be at least 4 characters long' },
      // { type: 'maxlength', message: 'Email cannot be more than 10 characters long' },
      { type: 'pattern', message: 'Please enter valid email' }
    ],


    'gender': [
      { type: 'required', message: 'Gender is required' }
    ],

     'bday': [
      { type: 'required', message: 'Birthday is required' }
    ],


    'phone': [
      { type: 'required', message: 'Mobile number is required' },
      { type: 'minlength', message: 'Mobile number must be at contain 10 characters long' },
      { type: 'maxlength', message: 'Mobile number must be at contain 10 characters long' },
      { type: 'pattern', message: 'Mobile number must contain only numbers' }
    ]

  }

}
