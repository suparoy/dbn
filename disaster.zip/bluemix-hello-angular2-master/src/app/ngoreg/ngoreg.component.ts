import { Component, OnInit, Inject } from '@angular/core';
import { NGORegisterService } from '../services/ngoregister/ngoregister.service';

import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-maps',
  templateUrl: './ngoreg.component.html',
  styleUrls: ['./ngoreg.component.css']
})
export class NGORegComponent implements OnInit {
  ngo: any;
  shelter: boolean;
  medical: boolean;
  serviceProvide: any;
  response: any;
  error: any;
  angForm: FormGroup;
  constructor( @Inject(NGORegisterService) private ngoRegisterService: NGORegisterService, private fb: FormBuilder) {
    this.ngo = {};
    this.serviceProvide=[];
  }

  ngoRegister() {
    console.log("here calling shelter......."+ this.shelter)
    if (this.shelter) {
      this.serviceProvide.push('Shelter');
    }
    if (this.medical) {
      this.serviceProvide.push('Medical');
    }
    this.ngo.ServicesProvide = this.serviceProvide;
    this.ngo["$class"] = "org.disaster.model.NGO";
    console.log("here calling servie.......")
    this.ngoRegisterService.NGORegister(this.ngo).subscribe((data: any) => {

      this.response = data;
      console.log(data);
    }, error => {
      this.error = error // error path);

      console.log(this.error);
    }
    );
  }

  //    this.angForm = this.formBuilder.group({
  // 	username: new FormControl('', Validators.required),
  // 	email: new FormControl('', Validators.compose([
  // 		Validators.required,
  // 		Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
  // 	]))
  // });
  ngOnInit() {

    this.angForm = new FormGroup({
      name: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.minLength(5),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      global: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(10),
        Validators.minLength(4),
        Validators.pattern('^[0-9]+$')
      ])),

      admin: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.minLength(5),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),

      branches: new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(4),
        Validators.pattern('^[A-Za-z0-9, ]+$')
      ])),

      phone: new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
        Validators.pattern('^[0-9]+$')
        // Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),

      shelter: new FormControl(''),
      medical: new FormControl(''),
       password: new FormControl(''),
      repassword: new FormControl('')


    })
  }

  account_validation_messages = {
    'name': [
      { type: 'required', message: 'Name is required' },
      { type: 'minlength', message: 'Name must be at least 5 characters long' },
      { type: 'maxlength', message: 'Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Name must contain only letters' }
    ],

    'global': [
      { type: 'required', message: 'Global Id is required' },
      { type: 'minlength', message: 'Global Id must be at least 4 characters long' },
      { type: 'maxlength', message: 'Global Id cannot be more than 10 characters long' },
      { type: 'pattern', message: 'Global Id must contain only numbers' }
    ],

    'admin': [
      { type: 'required', message: 'Admin is required' },
      { type: 'minlength', message: 'Admin must be at least 4 characters long' },
      { type: 'maxlength', message: 'Admin cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Admin must contain only letters' }
    ],

    'email': [
      { type: 'required', message: 'Email is required' },
      // { type: 'minlength', message: 'Email must be at least 4 characters long' },
      // { type: 'maxlength', message: 'Email cannot be more than 10 characters long' },
      { type: 'pattern', message: 'Email must contain only numbers' }
    ],

    'branches': [
      { type: 'required', message: 'Branches is required' },
      { type: 'minlength', message: 'Email must be at least 4 characters long' },
      // { type: 'maxlength', message: 'Email cannot be more than 10 characters long' },
      { type: 'pattern', message: 'Branches must contain only letters and numbers' }
    ],

    'phone': [
      { type: 'required', message: 'Mobile number is required' },
      { type: 'minlength', message: 'Mobile number must be at contain 10 characters long' },
      { type: 'maxlength', message: 'Mobile number must be at contain 10 characters long' },
      { type: 'pattern', message: 'Mobile number must contain only numbers' }
    ]

  }

}
