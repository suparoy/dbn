import { Component, OnInit } from '@angular/core';
import {AppComponent} from '../app.component'
import { WeatherapiService } from  '../services/weatherapi/weatherapi.service';
import { ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  
  lat: number;
  lng: number;
  disasterEvent:any;
// currentWeather:any;
// currentDayShift:any;
//  changeWeather(currentWeather,currentDayShift){
//         this.changeWeather=currentWeather;
//         this.currentDayShift=currentDayShift;
//     }
constructor(private activatedRoute: ActivatedRoute,private router:Router){
 this.disasterEvent=1;
}
sub;

ngOnInit() {
 if (window.navigator && window.navigator.geolocation) {
        window.navigator.geolocation.getCurrentPosition(
            position => {
                this.lat = position.coords.latitude,
                this.lng = position.coords.longitude,
                    console.log(position)
            },
            error => {
                switch (error.code) {
                    case 1:
                        console.log('Permission Denied');
                        break;
                    case 2:
                        console.log('Position Unavailable');
                        break;
                    case 3:
                        console.log('Timeout');
                        break;
                }
            }
        );
    };
     console.log("calling init")
    this.sub = this.activatedRoute.queryParams
                    .subscribe(params => { 
                     this.disasterEvent = +params['disasterEvent']||0;
                     console.log('Query in account params ',this.disasterEvent);
                     console.log('Query in account real params ',params['disasterEvent']);
                    });

}

onItemChange(value){
  
   console.log("calling here itemChange function: "+ value);
   this.disasterEvent=value;
   this.router.navigate(['./'], { queryParams: { disasterEvent: this.disasterEvent },relativeTo: this.activatedRoute });
 
 }
    

  }

  