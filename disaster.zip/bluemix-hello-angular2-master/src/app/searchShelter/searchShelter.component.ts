import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-search-shelter',
  templateUrl: './searchShelter.component.html',
  styleUrls: ['./searchShelter.component.css']
})
export class SearchShelterComponent implements OnInit {
  availShelters:any;
  disasterEvent:any;
  sub;
  constructor(private activatedRoute: ActivatedRoute,private router:Router) {
   // this.disasterEvent=1;
    this.availShelters=[
  {
    "$class": "org.disaster.model.Shelter",
    "Shelter_Id": "Shelter1",
    "Total_Capacity": 300,
    "location": {
      "$class": "org.disaster.model.Location",
      "latitude": "21",
      "longitude": "25"
    },
    "CurrentPeople": 0,
    "Contact": "+0342-9087659",
    "No_Of_doctors": 12,
    "No_Of_Volunteer": 60,
    "available_Equipment": [
      {
        "$class": "org.disaster.model.Available_Equipment",
        "Equipment_Name": "xyz",
        "Count": "10"
      },
      {
        "$class": "org.disaster.model.Available_Equipment",
        "Equipment_Name": "abc",
        "Count": "12"
      }
    ],
    "available_Amenities": [
      {
        "$class": "org.disaster.model.Available_Amenities",
        "Amenities_Name": "cde",
        "Count": "20"
      }
    ],
    "resident": [
      {
        "$class": "org.disaster.model.ResidentUpdate",
        "Name": "Suparna Roy",
        "Father_Name": "Swapan Kumar Roy",
        "DOB": "22 Mar 1993",
        "Address": "Burdwan, Kolkata",
        "Resident_Email": "suparnaroy@gmail.com",
        "Contact": "7797549390",
        "Biometric": "mIyo=",
        "BloodGroup": "A+",
        "shelter": []
      }
    ],
    "ngo": "resource:org.disaster.model.NGO#8017"
  },
  {
    "$class": "org.disaster.model.Shelter",
    "Shelter_Id": "Shelter2",
    "Total_Capacity": 300,
    "location": {
      "$class": "org.disaster.model.Location",
      "latitude": "21",
      "longitude": "25"
    },
    "CurrentPeople": 0,
    "Contact": "+0342-9087659",
    "No_Of_doctors": 12,
    "No_Of_Volunteer": 60,
    "available_Equipment": [
      {
        "$class": "org.disaster.model.Available_Equipment",
        "Equipment_Name": "xyz",
        "Count": "10"
      },
      {
        "$class": "org.disaster.model.Available_Equipment",
        "Equipment_Name": "abc",
        "Count": "12"
      }
    ],
    "available_Amenities": [
      {
        "$class": "org.disaster.model.Available_Amenities",
        "Amenities_Name": "cde",
        "Count": "20"
      }
    ],
    "resident": [],
    "ngo": "resource:org.disaster.model.NGO#8016"
  }
]
  }

  ngOnInit() {
    console.log("calling init")
    this.sub = this.activatedRoute.queryParams
                    .subscribe(params => { 
                     this.disasterEvent = +params['disasterEvent']||0;
                     console.log('Query params ',this.disasterEvent) });
   }

   onItemChange(value){
  
   console.log("calling here itemChange function: "+ value);
   this.disasterEvent=value;
   //this.router.navigate(['./home'], { queryParams: { disasterEvent: this.disasterEvent },relativeTo: this.activatedRoute });
 
 }
  //  this.disasterEvent = this.activatedRoute.snapshot.queryParamMap.get('disasterEvent');
  //  console.log("disaster event is: "+ this.disasterEvent);
  //}

}
