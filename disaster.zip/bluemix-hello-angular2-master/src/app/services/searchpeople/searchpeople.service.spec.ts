import { TestBed, inject } from '@angular/core/testing';

import { SearchpeopleService } from './searchpeople.service';

describe('SearchpeopleService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SearchpeopleService]
    });
  });

  it('should be created', inject([SearchpeopleService], (service: SearchpeopleService) => {
    expect(service).toBeTruthy();
  }));
});
