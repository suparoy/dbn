import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from  '@angular/common/http';

import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token'
  })
};


@Injectable({
  providedIn: 'root'
})
export class LogoutService {

   API_URL  =  "http://ec2-18-216-142-134.us-east-2.compute.amazonaws.com:3000/api/NGO";
 constructor(private  httpClient:  HttpClient) {}
 logout(user){
    return  this.httpClient.post(`${this.API_URL}`,user,httpOptions);
}
}
