import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { UserRegComponent } from './userreg/userreg.component';
import { AccountComponent } from './account/account.component';
import { AgmCoreModule } from '@agm/core';
import { WeatherapiService } from  './services/weatherapi/weatherapi.service';
import { NGORegisterService } from  './services/ngoregister/ngoregister.service';
import { UserRegisterService } from  './services/userregister/userregister.service';
import { HttpClientModule } from '@angular/common/http';
import { NGORegComponent } from './ngoreg/ngoreg.component';
import { PeopleSearchComponent } from './searchPeople/searchPeople.component';
import { ViewprofileComponent } from './viewprofile/viewprofile.component';
import { ChangepwdComponent } from './changepwd/changepwd.component';
import { SearchShelterComponent } from './searchShelter/searchShelter.component';
import { LoginService } from './services/login/login.service';
import { LogoutService } from './services/logout/logout.service';



const routes: Routes = [
  { path: '', redirectTo:'/home',pathMatch: 'full'},
  { path: 'home',component: AccountComponent},
  { path: 'userReg', component: UserRegComponent },
  { path: 'ngoReg', component: NGORegComponent },
   { path: 'searchPeople', component: PeopleSearchComponent },
    { path: 'viewProfile', component: ViewprofileComponent },
     { path: 'changePwd', component: ChangepwdComponent },
      { path: 'searchShelters', component: SearchShelterComponent },
      {path: 'app', component: AppComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    UserRegComponent,
    AccountComponent,
    NGORegComponent,
    PeopleSearchComponent,
    ViewprofileComponent,
    ChangepwdComponent,
    SearchShelterComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAMheM_sM-6szkdoyBEeEjgPDqBe5W4pnE'
    }),
     HttpClientModule,
     FormsModule,
      ReactiveFormsModule
  ],
  providers: [WeatherapiService,
LoginService,
  NGORegisterService,
  UserRegisterService,
  LogoutService
  ],
  bootstrap: [AppComponent]
})


export class AppModule { 
}
