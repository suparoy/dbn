import { Component,OnInit } from '@angular/core';
import { WeatherapiService } from  './services/weatherapi/weatherapi.service';
import { ChangepwdService } from  './services/changepwd/changepwd.service';
import { LoginService } from  './services/login/login.service';
import { LogoutService } from  './services/logout/logout.service';
import { ActivatedRoute,Router} from '@angular/router';

import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  netImage:any;
  newUser:any;
  login:boolean;
  error:any;
  angForm: FormGroup;
   angForm1: FormGroup;
   disasterEvent:any;
   sub;
 user:any={
    "$class": "org.disaster.model.Resident",
    "Name": "Swati",
    "Father_Name": "Harendra",
    "DOB": "01 Nov 1993",
    "Address": "Bihar",
    "Resident_Email": "des@gmail.com",
    "Contact": "746874612",
    "Biometric": "vBIyPO=",
    "BloodGroup": "O+",
    "shelter": []
  }
  private  weather:any={
    "metadata": {
        "language": "en-US",
        "transaction_id": "1533116207686:425726404",
        "version": "1",
        "latitude": 12.94,
        "longitude": 77.64,
        "units": "e",
        "expire_time_gmt": 1533117410,
        "status_code": 200
    },
    "forecasts": [
        {
            "class": "fod_long_range_daily",
            "expire_time_gmt": 1533117410,
            "fcst_valid": 1533087000,
            "fcst_valid_local": "2018-08-01T07:00:00+0530",
            "num": 1,
            "max_temp": 81,
            "min_temp": 68,
            "torcon": null,
            "stormcon": null,
            "blurb": null,
            "blurb_author": null,
            "lunar_phase_day": 19,
            "dow": "Wednesday",
            "lunar_phase": "Waning Gibbous",
            "lunar_phase_code": "WNG",
            "sunrise": "2018-08-01T06:04:49+0530",
            "sunset": "2018-08-01T18:46:43+0530",
            "moonrise": "2018-08-01T21:59:04+0530",
            "moonset": "2018-08-01T09:28:40+0530",
            "qualifier_code": null,
            "qualifier": null,
            "narrative": "Thunderstorms. Highs in the low 80s and lows in the upper 60s.",
            "qpf": 0.03,
            "snow_qpf": 0,
            "snow_range": "",
            "snow_phrase": "",
            "snow_code": "",
            "night": {
                "fcst_valid": 1533130200,
                "fcst_valid_local": "2018-08-01T19:00:00+0530",
                "day_ind": "N",
                "thunder_enum": 0,
                "daypart_name": "Tonight",
                "long_daypart_name": "Wednesday night",
                "alt_daypart_name": "Tonight",
                "thunder_enum_phrase": "No thunder",
                "num": 2,
                "temp": 68,
                "hi": 81,
                "wc": 69,
                "pop": 10,
                "icon_extd": 2900,
                "icon_code": 29,
                "wxman": "wx1600",
                "phrase_12char": "P Cloudy",
                "phrase_22char": "Partly Cloudy",
                "phrase_32char": "Partly Cloudy",
                "subphrase_pt1": "Partly",
                "subphrase_pt2": "Cloudy",
                "subphrase_pt3": "",
                "precip_type": "rain",
                "rh": 91,
                "wspd": 12,
                "wdir": 262,
                "wdir_cardinal": "W",
                "clds": 51,
                "pop_phrase": "",
                "temp_phrase": "Low 68F.",
                "accumulation_phrase": "",
                "wind_phrase": "Winds W at 10 to 15 mph.",
                "shortcast": "Partly cloudy",
                "narrative": "Some clouds. Low 68F. Winds W at 10 to 15 mph.",
                "qpf": 0,
                "snow_qpf": 0,
                "snow_range": "",
                "snow_phrase": "",
                "snow_code": "",
                "vocal_key": "D2:DA02:X3000300024:S300023:TL68:W12R03",
                "qualifier_code": null,
                "qualifier": null,
                "uv_index_raw": 0,
                "uv_index": 0,
                "uv_warning": 0,
                "uv_desc": "Low",
                "golf_index": null,
                "golf_category": ""
            },
            "day": {
                "fcst_valid": 1533087000,
                "fcst_valid_local": "2018-08-01T07:00:00+0530",
                "day_ind": "D",
                "thunder_enum": 2,
                "daypart_name": "Today",
                "long_daypart_name": "Wednesday",
                "alt_daypart_name": "This afternoon",
                "thunder_enum_phrase": "Thunder expected",
                "num": 1,
                "temp": 81,
                "hi": 84,
                "wc": 77,
                "pop": 80,
                "icon_extd": 400,
                "icon_code": 4,
                "wxman": "wx6500",
                "phrase_12char": "T-Storms",
                "phrase_22char": "Thunderstorms",
                "phrase_32char": "Thunderstorms",
                "subphrase_pt1": "T-Storms",
                "subphrase_pt2": "",
                "subphrase_pt3": "",
                "precip_type": "rain",
                "rh": 70,
                "wspd": 12,
                "wdir": 261,
                "wdir_cardinal": "W",
                "clds": 74,
                "pop_phrase": "Chance of rain 80%.",
                "temp_phrase": "High 81F.",
                "accumulation_phrase": "",
                "wind_phrase": "Winds W at 10 to 15 mph.",
                "shortcast": "Showers and thunderstorms",
                "narrative": "Thunderstorms likely. High 81F. Winds W at 10 to 15 mph. Chance of rain 80%.",
                "qpf": 0.03,
                "snow_qpf": 0,
                "snow_range": "",
                "snow_phrase": "",
                "snow_code": "",
                "vocal_key": "D1:DA18:X0400040012:S040012:TH81:W12R03:P9081",
                "qualifier_code": null,
                "qualifier": null,
                "uv_index_raw": 6.4,
                "uv_index": 6,
                "uv_warning": 0,
                "uv_desc": "High",
                "golf_index": 3,
                "golf_category": "Poor"
            }
        },
        {
            "class": "fod_long_range_daily",
            "expire_time_gmt": 1533117410,
            "fcst_valid": 1533173400,
            "fcst_valid_local": "2018-08-02T07:00:00+0530",
            "num": 2,
            "max_temp": 84,
            "min_temp": 67,
            "torcon": null,
            "stormcon": null,
            "blurb": null,
            "blurb_author": null,
            "lunar_phase_day": 19,
            "dow": "Thursday",
            "lunar_phase": "Waning Gibbous",
            "lunar_phase_code": "WNG",
            "sunrise": "2018-08-02T06:05:01+0530",
            "sunset": "2018-08-02T18:46:22+0530",
            "moonrise": "2018-08-02T22:39:12+0530",
            "moonset": "2018-08-02T10:16:32+0530",
            "qualifier_code": null,
            "qualifier": null,
            "narrative": "Mostly cloudy. Highs in the mid 80s and lows in the upper 60s.",
            "qpf": 0,
            "snow_qpf": 0,
            "snow_range": "",
            "snow_phrase": "",
            "snow_code": "",
            "night": {
                "fcst_valid": 1533216600,
                "fcst_valid_local": "2018-08-02T19:00:00+0530",
                "day_ind": "N",
                "thunder_enum": 0,
                "daypart_name": "Tomorrow night",
                "long_daypart_name": "Thursday night",
                "alt_daypart_name": "Thursday night",
                "thunder_enum_phrase": "No thunder",
                "num": 4,
                "temp": 67,
                "hi": 83,
                "wc": 68,
                "pop": 20,
                "icon_extd": 2900,
                "icon_code": 29,
                "wxman": "wx1600",
                "phrase_12char": "P Cloudy",
                "phrase_22char": "Partly Cloudy",
                "phrase_32char": "Partly Cloudy",
                "subphrase_pt1": "Partly",
                "subphrase_pt2": "Cloudy",
                "subphrase_pt3": "",
                "precip_type": "rain",
                "rh": 90,
                "wspd": 11,
                "wdir": 268,
                "wdir_cardinal": "W",
                "clds": 53,
                "pop_phrase": "",
                "temp_phrase": "Low 67F.",
                "accumulation_phrase": "",
                "wind_phrase": "Winds W at 10 to 15 mph.",
                "shortcast": "Partly cloudy",
                "narrative": "A few clouds. Low 67F. Winds W at 10 to 15 mph.",
                "qpf": 0,
                "snow_qpf": 0,
                "snow_range": "",
                "snow_phrase": "",
                "snow_code": "",
                "vocal_key": "D4:DA13:X3000300044:S300043:TL67:W12R03",
                "qualifier_code": null,
                "qualifier": null,
                "uv_index_raw": 0,
                "uv_index": 0,
                "uv_warning": 0,
                "uv_desc": "Low",
                "golf_index": null,
                "golf_category": ""
            },
            "day": {
                "fcst_valid": 1533173400,
                "fcst_valid_local": "2018-08-02T07:00:00+0530",
                "day_ind": "D",
                "thunder_enum": 0,
                "daypart_name": "Tomorrow",
                "long_daypart_name": "Thursday",
                "alt_daypart_name": "Thursday",
                "thunder_enum_phrase": "No thunder",
                "num": 3,
                "temp": 84,
                "hi": 86,
                "wc": 69,
                "pop": 20,
                "icon_extd": 2800,
                "icon_code": 28,
                "wxman": "wx1200",
                "phrase_12char": "M Cloudy",
                "phrase_22char": "Mostly Cloudy",
                "phrase_32char": "Mostly Cloudy",
                "subphrase_pt1": "Mostly",
                "subphrase_pt2": "Cloudy",
                "subphrase_pt3": "",
                "precip_type": "rain",
                "rh": 75,
                "wspd": 14,
                "wdir": 269,
                "wdir_cardinal": "W",
                "clds": 74,
                "pop_phrase": "",
                "temp_phrase": "High 84F.",
                "accumulation_phrase": "",
                "wind_phrase": "Winds W at 10 to 20 mph.",
                "shortcast": "Considerable cloudiness",
                "narrative": "Mostly cloudy skies. High 84F. Winds W at 10 to 20 mph.",
                "qpf": 0,
                "snow_qpf": 0,
                "snow_range": "",
                "snow_phrase": "",
                "snow_code": "",
                "vocal_key": "D3:DA12:X2600280032:S280032:TH84:W12R04",
                "qualifier_code": null,
                "qualifier": null,
                "uv_index_raw": 10.66,
                "uv_index": 11,
                "uv_warning": 1,
                "uv_desc": "Extreme",
                "golf_index": 9,
                "golf_category": "Very Good"
            }
        },
        {
            "class": "fod_long_range_daily",
            "expire_time_gmt": 1533117410,
            "fcst_valid": 1533259800,
            "fcst_valid_local": "2018-08-03T07:00:00+0530",
            "num": 3,
            "max_temp": 84,
            "min_temp": 67,
            "torcon": null,
            "stormcon": null,
            "blurb": null,
            "blurb_author": null,
            "lunar_phase_day": 20,
            "dow": "Friday",
            "lunar_phase": "Waning Gibbous",
            "lunar_phase_code": "WNG",
            "sunrise": "2018-08-03T06:05:13+0530",
            "sunset": "2018-08-03T18:46:01+0530",
            "moonrise": "2018-08-03T23:20:20+0530",
            "moonset": "2018-08-03T11:05:56+0530",
            "qualifier_code": null,
            "qualifier": null,
            "narrative": "Times of sun and clouds. Highs in the mid 80s and lows in the upper 60s.",
            "qpf": 0,
            "snow_qpf": 0,
            "snow_range": "",
            "snow_phrase": "",
            "snow_code": "",
            "night": {
                "fcst_valid": 1533303000,
                "fcst_valid_local": "2018-08-03T19:00:00+0530",
                "day_ind": "N",
                "thunder_enum": 0,
                "daypart_name": "Friday night",
                "long_daypart_name": "Friday night",
                "alt_daypart_name": "Friday night",
                "thunder_enum_phrase": "No thunder",
                "num": 6,
                "temp": 67,
                "hi": 82,
                "wc": 68,
                "pop": 20,
                "icon_extd": 2900,
                "icon_code": 29,
                "wxman": "wx1600",
                "phrase_12char": "P Cloudy",
                "phrase_22char": "Partly Cloudy",
                "phrase_32char": "Partly Cloudy",
                "subphrase_pt1": "Partly",
                "subphrase_pt2": "Cloudy",
                "subphrase_pt3": "",
                "precip_type": "rain",
                "rh": 87,
                "wspd": 11,
                "wdir": 273,
                "wdir_cardinal": "W",
                "clds": 47,
                "pop_phrase": "",
                "temp_phrase": "Low 67F.",
                "accumulation_phrase": "",
                "wind_phrase": "Winds W at 10 to 15 mph.",
                "shortcast": "Partly cloudy",
                "narrative": "Partly cloudy skies. Low 67F. Winds W at 10 to 15 mph.",
                "qpf": 0,
                "snow_qpf": 0,
                "snow_range": "",
                "snow_phrase": "",
                "snow_code": "",
                "vocal_key": "D6:DA15:X3000300041:S300041:TL67:W12R03",
                "qualifier_code": null,
                "qualifier": null,
                "uv_index_raw": 0,
                "uv_index": 0,
                "uv_warning": 0,
                "uv_desc": "Low",
                "golf_index": null,
                "golf_category": ""
            },
            "day": {
                "fcst_valid": 1533259800,
                "fcst_valid_local": "2018-08-03T07:00:00+0530",
                "day_ind": "D",
                "thunder_enum": 0,
                "daypart_name": "Friday",
                "long_daypart_name": "Friday",
                "alt_daypart_name": "Friday",
                "thunder_enum_phrase": "No thunder",
                "num": 5,
                "temp": 84,
                "hi": 86,
                "wc": 68,
                "pop": 10,
                "icon_extd": 3000,
                "icon_code": 30,
                "wxman": "wx1100",
                "phrase_12char": "P Cloudy",
                "phrase_22char": "Partly Cloudy",
                "phrase_32char": "Partly Cloudy",
                "subphrase_pt1": "Partly",
                "subphrase_pt2": "Cloudy",
                "subphrase_pt3": "",
                "precip_type": "rain",
                "rh": 73,
                "wspd": 15,
                "wdir": 277,
                "wdir_cardinal": "W",
                "clds": 53,
                "pop_phrase": "",
                "temp_phrase": "High 84F.",
                "accumulation_phrase": "",
                "wind_phrase": "Winds W at 10 to 20 mph.",
                "shortcast": "Times of sun and clouds",
                "narrative": "Mostly cloudy skies early, then partly cloudy in the afternoon. High 84F. Winds W at 10 to 20 mph.",
                "qpf": 0,
                "snow_qpf": 0,
                "snow_range": "",
                "snow_phrase": "",
                "snow_code": "",
                "vocal_key": "D5:DA14:X2800300032:S300033:TH84:W12R04",
                "qualifier_code": null,
                "qualifier": null,
                "uv_index_raw": 13.5,
                "uv_index": 11,
                "uv_warning": 1,
                "uv_desc": "Extreme",
                "golf_index": 9,
                "golf_category": "Very Good"
            }
        },
        {
            "class": "fod_long_range_daily",
            "expire_time_gmt": 1533117410,
            "fcst_valid": 1533346200,
            "fcst_valid_local": "2018-08-04T07:00:00+0530",
            "num": 4,
            "max_temp": 84,
            "min_temp": 67,
            "torcon": null,
            "stormcon": null,
            "blurb": null,
            "blurb_author": null,
            "lunar_phase_day": 21,
            "dow": "Saturday",
            "lunar_phase": "Waning Gibbous",
            "lunar_phase_code": "WNG",
            "sunrise": "2018-08-04T06:05:24+0530",
            "sunset": "2018-08-04T18:45:39+0530",
            "moonrise": "",
            "moonset": "2018-08-04T11:56:15+0530",
            "qualifier_code": null,
            "qualifier": null,
            "narrative": "Times of sun and clouds. Highs in the mid 80s and lows in the upper 60s.",
            "qpf": 0,
            "snow_qpf": 0,
            "snow_range": "",
            "snow_phrase": "",
            "snow_code": "",
            "night": {
                "fcst_valid": 1533389400,
                "fcst_valid_local": "2018-08-04T19:00:00+0530",
                "day_ind": "N",
                "thunder_enum": 0,
                "daypart_name": "Saturday night",
                "long_daypart_name": "Saturday night",
                "alt_daypart_name": "Saturday night",
                "thunder_enum_phrase": "No thunder",
                "num": 8,
                "temp": 67,
                "hi": 82,
                "wc": 68,
                "pop": 10,
                "icon_extd": 2900,
                "icon_code": 29,
                "wxman": "wx1600",
                "phrase_12char": "P Cloudy",
                "phrase_22char": "Partly Cloudy",
                "phrase_32char": "Partly Cloudy",
                "subphrase_pt1": "Partly",
                "subphrase_pt2": "Cloudy",
                "subphrase_pt3": "",
                "precip_type": "rain",
                "rh": 86,
                "wspd": 12,
                "wdir": 277,
                "wdir_cardinal": "W",
                "clds": 47,
                "pop_phrase": "",
                "temp_phrase": "Low 67F.",
                "accumulation_phrase": "",
                "wind_phrase": "Winds W at 10 to 15 mph.",
                "shortcast": "Partly cloudy",
                "narrative": "A few clouds from time to time. Low 67F. Winds W at 10 to 15 mph.",
                "qpf": 0,
                "snow_qpf": 0,
                "snow_range": "",
                "snow_phrase": "",
                "snow_code": "",
                "vocal_key": "D8:DA17:X3000300042:S300043:TL67:W12R03",
                "qualifier_code": null,
                "qualifier": null,
                "uv_index_raw": 0,
                "uv_index": 0,
                "uv_warning": 0,
                "uv_desc": "Low",
                "golf_index": null,
                "golf_category": ""
            },
            "day": {
                "fcst_valid": 1533346200,
                "fcst_valid_local": "2018-08-04T07:00:00+0530",
                "day_ind": "D",
                "thunder_enum": 0,
                "daypart_name": "Saturday",
                "long_daypart_name": "Saturday",
                "alt_daypart_name": "Saturday",
                "thunder_enum_phrase": "No thunder",
                "num": 7,
                "temp": 84,
                "hi": 85,
                "wc": 69,
                "pop": 10,
                "icon_extd": 3000,
                "icon_code": 30,
                "wxman": "wx1100",
                "phrase_12char": "P Cloudy",
                "phrase_22char": "Partly Cloudy",
                "phrase_32char": "Partly Cloudy",
                "subphrase_pt1": "Partly",
                "subphrase_pt2": "Cloudy",
                "subphrase_pt3": "",
                "precip_type": "rain",
                "rh": 73,
                "wspd": 16,
                "wdir": 280,
                "wdir_cardinal": "W",
                "clds": 63,
                "pop_phrase": "",
                "temp_phrase": "High 84F.",
                "accumulation_phrase": "",
                "wind_phrase": "Winds W at 10 to 20 mph.",
                "shortcast": "Mix of sun and clouds",
                "narrative": "Considerable clouds early. Some decrease in clouds later in the day. High 84F. Winds W at 10 to 20 mph.",
                "qpf": 0,
                "snow_qpf": 0,
                "snow_range": "",
                "snow_phrase": "",
                "snow_code": "",
                "vocal_key": "D7:DA16:X2800300034:S300032:TH84:W12R04",
                "qualifier_code": null,
                "qualifier": null,
                "uv_index_raw": 12.28,
                "uv_index": 11,
                "uv_warning": 1,
                "uv_desc": "Extreme",
                "golf_index": 9,
                "golf_category": "Very Good"
            }
        }
    ]
};
temp:number;
humidity:number;
weatherdesc:number;
presentday:string;
currentWeather:any;
currentDayShift:any;
  constructor(private activatedRoute:ActivatedRoute,private router:Router,private  logoutService:  LogoutService,private  loginService:  LoginService,private  weatherapiService:  WeatherapiService,  private fb: FormBuilder, private  changepwdService: ChangepwdService  ) {
     this.newUser={};
     this.login=false;
     this.disasterEvent=0;
    this.currentWeather=this.weather.forecasts[0];
    if(Date.parse(new Date().toString())>=Date.parse(this.currentWeather.sunset)){
        this.currentDayShift=this.currentWeather.night;
       this.netImage= "../assets/weathericons/icon"+this.currentDayShift.icon_code+".png";
      this.temp=Math.round((this.currentDayShift.temp-32)/1.8);
      this.humidity=this.currentDayShift.rh;
      this.weatherdesc=this.currentDayShift.phrase_22char;
      this.presentday=this.currentDayShift.fcst_valid_local;
    }else{
        this.currentDayShift=this.currentWeather.day;
       this.netImage= "../assets/weathericons/icon"+this.weather.forecasts[0].day.icon_code+".png";
      this.temp=Math.round((this.currentDayShift.temp-32)/1.8);
      this.humidity=this.currentDayShift.rh;
      this.weatherdesc=this.currentDayShift.phrase_22char;
      this.presentday=this.currentDayShift.fcst_valid_local;
    }
     
  }
    changeWeather(currentWeather:any,currentDayShift:any){
         this.presentday=currentWeather.fcst_valid_local;
         this.weatherdesc=currentDayShift.phrase_22char;
         this.humidity=currentDayShift.rh;
         this.temp=Math.round((currentDayShift.temp-32)/1.8);
         this.netImage= "../assets/weathericons/icon"+currentDayShift.icon_code+".png";
         this.currentWeather=currentWeather;
    }

    getWeather(){
   
    this.weatherapiService.getWeatherDetails().subscribe((data: any) => {

        this.weather  =  data;
        console.log(data);
      }, error => {
        this.error = error // error path);
       
       console.log(this.error);
      }
    );
 
 }

changeRespone:any;
 changePwd(){
   
    this.changepwdService.changePwd(this.newUser).subscribe((data: any) => {

        this.changeRespone  =  data;
        console.log(data);
      }, error => {
        this.error = error // error path);
       
       console.log(this.error);
      }
    );
 
 }

 userLogin(){
   this.login=true;
   console.log("calling here login function: "+ this.login);
    this.loginService.login(this.user).subscribe((data: any) => {

        //this.login  =  data;
        this.login=true;
        console.log(data);
      }, error => {
        this.error = error // error path);
       //this.login=false;
       console.log(this.error);
      }
    );
 
 }

  logout(){
   this.login=false;
   console.log("calling here logout function: "+ this.login);
    this.logoutService.logout(this.user).subscribe((data: any) => {

        //this.login  =  data;
        this.login=false;
        console.log(data);
      }, error => {
        this.error = error // error path);
       //this.login=false;
       console.log(this.error);
      }
    );
 
 }

 onItemChange(value){
  
   console.log("calling here itemChange function: "+ value);
   this.disasterEvent=value;
   this.router.navigate(['./home'], { queryParams: { disasterEvent: this.disasterEvent },relativeTo: this.activatedRoute });
 
 }

  skip(){
  
   console.log("calling here skip function: ");
   this.disasterEvent=0;
   this.router.navigate(['./home'], { queryParams: { disasterEvent: this.disasterEvent },relativeTo: this.activatedRoute });
    
 
 }


 ngOnInit(){
  // this.getWeather();
  this.angForm = new FormGroup({

       password: new FormControl('',Validators.compose([
        Validators.required
        // Validators.minLength(10),
        // Validators.maxLength(10),
        // Validators.pattern('^[0-9]+$')
        // Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),
      repassword: new FormControl('',Validators.compose([
        Validators.required
        // Validators.minLength(10),
        // Validators.maxLength(10),
        // Validators.pattern('^[0-9]+$')
        // Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ]))

  })

   this.angForm1 = new FormGroup({

       username: new FormControl('',Validators.compose([
        Validators.required,
        // Validators.minLength(10),
        // Validators.maxLength(10),
        // Validators.pattern('^[0-9]+$')
         Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),
      password: new FormControl('',Validators.compose([
        Validators.required
        // Validators.minLength(10),
        // Validators.maxLength(10),
        // Validators.pattern('^[0-9]+$')
        // Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ]))

  })

  this.sub = this.activatedRoute.queryParams
                    .subscribe(params => { 
                     this.disasterEvent = +params['disasterEvent']||0;
                     console.log('Query in app params ',this.disasterEvent);
                     console.log('Query in app real params ',params['disasterEvent']);
                    });
 }

 account_validation_messages = {
     'password': [
      { type: 'required', message: 'Password is required' }
    //   { type: 'minlength', message: 'Admin must be at least 4 characters long' },
    //   { type: 'maxlength', message: 'Admin cannot be more than 25 characters long' },
    //   { type: 'pattern', message: 'Admin must contain only letters' }
    ],

     'username': [
      { type: 'required', message: 'username is required' },
    //   { type: 'minlength', message: 'Admin must be at least 4 characters long' },
    //   { type: 'maxlength', message: 'Admin cannot be more than 25 characters long' },
     { type: 'pattern', message: 'Please enter valid email' }
    ],


    'repassword': [
      { type: 'required', message: 'Confirm Password is required' }
    //   { type: 'minlength', message: 'Admin must be at least 4 characters long' },
    //   { type: 'maxlength', message: 'Admin cannot be more than 25 characters long' },
    //   { type: 'pattern', message: 'Admin must contain only letters' }
    ]
 }
}
