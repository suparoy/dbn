import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-changepwd',
  templateUrl: './changepwd.component.html',
  styleUrls: ['./changepwd.component.css']
})
export class ChangepwdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
