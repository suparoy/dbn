import { TestBed, inject } from '@angular/core/testing';

import { ChangepwdService } from './changepwd.service';

describe('ChangepwdService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ChangepwdService]
    });
  });

  it('should be created', inject([ChangepwdService], (service: ChangepwdService) => {
    expect(service).toBeTruthy();
  }));
});
