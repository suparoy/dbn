import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from  '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class WeatherapiService {
 API_URL  =  "https://5ae58f9f-4ded-4573-8bbe-0068d0e4fe62:pAaT4MnTuf@twcservice.mybluemix.net/api/weather/v1/geocode/12.949/77.649/forecast/daily/3day.json";
 constructor(private  httpClient:  HttpClient) {}
 getWeatherDetails(){
    return  this.httpClient.get(`${this.API_URL}`);
}
 
}
