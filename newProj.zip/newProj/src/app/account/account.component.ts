import { Component, OnInit } from '@angular/core';
import {AppComponent} from '../app.component'
import { WeatherapiService } from  '../services/weatherapi/weatherapi.service';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  
  lat: number;
  lng: number;
// currentWeather:any;
// currentDayShift:any;
//  changeWeather(currentWeather,currentDayShift){
//         this.changeWeather=currentWeather;
//         this.currentDayShift=currentDayShift;
//     }


ngOnInit() {
 if (window.navigator && window.navigator.geolocation) {
        window.navigator.geolocation.getCurrentPosition(
            position => {
                this.lat = position.coords.latitude,
                this.lng = position.coords.longitude,
                    console.log(position)
            },
            error => {
                switch (error.code) {
                    case 1:
                        console.log('Permission Denied');
                        break;
                    case 2:
                        console.log('Position Unavailable');
                        break;
                    case 3:
                        console.log('Timeout');
                        break;
                }
            }
        );
    };
     
    

  }

}