import { Component, OnInit, Inject } from '@angular/core';
import { SearchpeopleService } from '../services/searchpeople/searchpeople.service';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-search',
  templateUrl: './searchPeople.component.html',
  styleUrls: ['./searchPeople.component.css']
})
export class PeopleSearchComponent implements OnInit {
  user: any;
  response: any;
  error: any;
  angForm: FormGroup;
  showdiv:boolean;
  constructor( @Inject(SearchpeopleService) private searchpeopleService: SearchpeopleService, private fb: FormBuilder) {
    this.user = {};
    this.showdiv=false;
    this.user={
    "$class": "org.disaster.model.Resident",
    "Name": "Swati",
    "Father_Name": "Harendra",
    "DOB": "01 Nov 1993",
    "Address": "Bihar",
    "Resident_Email": "des@gmail.com",
    "Contact": "746874612",
    "Biometric": "vBIyPO=",
    "BloodGroup": "O+",
    "shelter": []
  }
  }
 
 searchPeople() {
  
    this.user["$class"] = "org.disaster.model.NGO";
    console.log("here calling servie.......")
    this.searchpeopleService.searchPeople(this.user).subscribe((data: any) => {

      this.response = data;
      console.log(data);
    }, error => {
      this.error = error // error path);

      console.log(this.error);
    }
    );
  }

  ngOnInit() {

    this.angForm = new FormGroup({
      name: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.minLength(5),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      fathername: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.minLength(5),
        Validators.pattern('^[A-Za-z ]+$')
      ]))

     
  
    })
  }

  account_validation_messages = {
    'name': [
      { type: 'required', message: 'Name is required' },
      { type: 'minlength', message: 'Name must be at least 5 characters long' },
      { type: 'maxlength', message: 'Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Name must contain only letters' }
    ],

     'fathername': [
      { type: 'required', message: 'Name is required' },
      { type: 'minlength', message: 'Name must be at least 5 characters long' },
      { type: 'maxlength', message: 'Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Name must contain only letters' }
    ]
  }

}
